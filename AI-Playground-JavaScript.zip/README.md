# AI-Playground-JavaScript

Tinker with a neural network in your browser. Self-made model without any calculus.

## TODO

- Bug: is it offset? (pixels are left + down of points?)
- Style 'select' elements
- Weight momentum
- ??
	- Plugins for weight initialization
    - Cost graph
    - Network visualization
- ITCH.IO page