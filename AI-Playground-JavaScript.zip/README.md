# AI-Playground-JavaScript

Tinker with a neural network in your browser. Self-made model without any calculus.

## TODO

- Plugins for weight initialization
    - Check if they are right!!
- Style 'select' elements
- Save/restore (like 3D ceullar automata)
- ??
    - Cost graph
    - Network visualization
- ITCH.IO page
