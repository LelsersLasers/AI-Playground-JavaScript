# AI-Playground-JavaScript

Tinker with a neural network in your browser. Self-made model without any calculus.

## TODO

- Plugins for weight initialization
    - Check if they are right!!
- Style 'select' elements
- ??
    - Cost graph
    - Network visualization
    - Format JS?
        - `npx prettier --write . --tab-width 4`
- ITCH.IO page
