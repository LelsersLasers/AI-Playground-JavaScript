# AI-Playground-JavaScript

Tinker with a neural network in your browser. Self-made model without any calculus.

## TODO

- Epoch counter
- Style 'select' elements
- Weight momentum
- ??
	- Plugins for weight initialization
    - Cost graph
    - Network visualization
- ITCH.IO page
