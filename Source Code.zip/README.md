# AI-Playground-JavaScript

Tinker with a neural network in your browser. Self-made model without any calculus.

Live demo at: https://lelserslasers.itch.io/ai-playground-js

## Showcase

![GIF 1](https://img.itch.zone/aW1hZ2UvMjA4NDIxNS8xMjI4MzUwMy5naWY=/347x500/A1lM0r.gif)
![GIF 2](https://img.itch.zone/aW1hZ2UvMjA4NDIxNS8xMjI4MzI2Ny5naWY=/347x500/iQb38f.gif)
![GIF 3](https://img.itch.zone/aW1hZ2UvMjA4NDIxNS8xMjI4MzMxNS5naWY=/347x500/2%2FzLSq.gif)
![Image 1](https://img.itch.zone/aW1hZ2UvMjA4NDIxNS8xMjI4NDM3MS5wbmc=/347x500/lHi53D.png)
![Image 2](https://img.itch.zone/aW1hZ2UvMjA4NDIxNS8xMjI4NDAyNi5wbmc=/347x500/rVGpP%2F.png)
